from django.apps import AppConfig


class SeguimientoFormulaConfig(AppConfig):
    name = 'seguimiento_formula'

from django.apps import AppConfig


class EstadoPlanConfig(AppConfig):
    name = 'estado_plan'

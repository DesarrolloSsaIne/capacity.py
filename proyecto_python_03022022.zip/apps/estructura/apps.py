from django.apps import AppConfig


class EstructuraConfig(AppConfig):
    name = 'estructura'

from django.contrib import admin
from django.contrib import admin
from apps.estructura.models import Ges_PrimerNivel

# Register your models here.


admin.site.register(Ges_PrimerNivel)
# Register your models here.

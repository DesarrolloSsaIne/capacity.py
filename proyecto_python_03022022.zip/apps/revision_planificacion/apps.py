from django.apps import AppConfig


class RevisionPlanificacionConfig(AppConfig):
    name = 'revision_planificacion'

from django.apps import AppConfig


class ValidaSeguimientoConfig(AppConfig):
    name = 'valida_seguimiento'

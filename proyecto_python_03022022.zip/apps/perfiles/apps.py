from django.apps import AppConfig


class PerfilesConfig(AppConfig):
    name = 'perfiles'

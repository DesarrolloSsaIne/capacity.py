from django.apps import AppConfig


class VistaObjetivosConfig(AppConfig):
    name = 'vista_objetivos'

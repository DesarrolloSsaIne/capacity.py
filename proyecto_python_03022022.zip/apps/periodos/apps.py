from django.apps import AppConfig


class PeriodosConfig(AppConfig):
    name = 'periodos'

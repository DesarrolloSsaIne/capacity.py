from django.apps import AppConfig


class FeriadosConfig(AppConfig):
    name = 'feriados'

from django.apps import AppConfig


class EstadoSeguimientoConfig(AppConfig):
    name = 'estado_seguimiento'

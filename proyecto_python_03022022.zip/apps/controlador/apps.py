from django.apps import AppConfig


class ControladorConfig(AppConfig):
    name = 'controlador'

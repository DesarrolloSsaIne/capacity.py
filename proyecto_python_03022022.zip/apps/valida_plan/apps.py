from django.apps import AppConfig


class ValidaPlanConfig(AppConfig):
    name = 'valida_plan'

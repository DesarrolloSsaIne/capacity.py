from django.apps import AppConfig


class GestionHorasConfig(AppConfig):
    name = 'gestion_horas'

from django.apps import AppConfig


class ActividadesConfig(AppConfig):
    name = 'actividades'

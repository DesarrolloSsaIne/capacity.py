from django.apps import AppConfig


class PeriodicidadConfig(AppConfig):
    name = 'periodicidad'

from django.apps import AppConfig


class PlanificacionAdminConfig(AppConfig):
    name = 'planificacion_admin'

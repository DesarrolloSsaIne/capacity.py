from django.apps import AppConfig


class EjeConfig(AppConfig):
    name = 'eje'

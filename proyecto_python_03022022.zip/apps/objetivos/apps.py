from django.apps import AppConfig


class ObjetivosConfig(AppConfig):
    name = 'objetivos'

from django.apps import AppConfig


class FamiliaCargoConfig(AppConfig):
    name = 'familia_cargo'

from django.apps import AppConfig


class EstadoFlujoConfig(AppConfig):
    name = 'estado_flujo'

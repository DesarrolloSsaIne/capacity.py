from django.apps import AppConfig


class JefaturasConfig(AppConfig):
    name = 'jefaturas'

from django.apps import AppConfig


class EstadoActividadConfig(AppConfig):
    name = 'estado_actividad'
